#include <iostream>
#include <string>
#include<bits/stdc++.h>
#include <unordered_map>
#include <list>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <netdb.h>


const int BUFFER_SIZE = 4096;


// Data structure to represent a web page
struct WebPage {
    std::string url;
    std::string content;
};

// Cache structure using an unordered map and a doubly-linked list
class WebCache {
public:
    WebCache(int size) : cache_size(size) {}

    std::string GetWebPage(const std::string& url) {
        if (cache_map.find(url) != cache_map.end()) {
            // Move the accessed page to the front of the list (MRU)
            MoveToFront(url);
            return cache_map[url].content;
        } else {
            // Page not in cache, fetch it
            std::string content = FetchWebPage(url);
            if(content=="") {
                std::cout<<"\033[1;31mNo content can be retrieved using http(url uses https protocol instead) or the intended webpage doesn't exist..Not cacheing\033[0m\n"<<std::endl;
            }
            else if(content=="Invalid URL"){
                std::cout<<"\033[1;31mThe intended webpage doesn't exist..Not cacheing\033[0m\n"<<std::endl;
            }
            else InsertWebPage(url, content);
            return content;
        }
    }

    void DisplayCache() {
        for (const auto& page : cache_list) {
            std::cout<<"\033[1;32m" << page.url <<"\033[0m\n"<< std::endl;
        }
    }

private:
    int cache_size;
    std::unordered_map<std::string, WebPage> cache_map;
    std::list<WebPage> cache_list;

    void MoveToFront(const std::string& url) {
        // Find the page in the list
        auto it = cache_list.begin();
        while (it != cache_list.end()) {
            if (it->url == url) {
                // Move the accessed page to the front
                cache_list.splice(cache_list.begin(), cache_list, it);
                break;
            }
            ++it;
        }
    }

    std::string FetchWebPage(const std::string& url) {
        // Parse the URL to extract the hostname and path
        std::string hostname, path;
        size_t http_pos = url.find("://");
        if (http_pos != std::string::npos) {
            http_pos += 3;
            size_t host_pos = url.find("/", http_pos);
            if (host_pos != std::string::npos) {
                hostname = url.substr(http_pos, host_pos - http_pos);
                path = url.substr(host_pos);
            } else {
                hostname = url.substr(http_pos);
                path = "/";
            }
        } else {
            // Invalid URL
            return "Invalid URL";
        }

        // Create a socket
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock == -1) {
            return "Socket creation error";
        }

        // Resolve the hostname to an IP address
        struct hostent* host_info = gethostbyname(hostname.c_str());
        if (!host_info) {
            close(sock);
            return "Hostname resolution error";
        }

        // Set up the server address
        struct sockaddr_in server_addr;
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(80);
        memcpy(&server_addr.sin_addr.s_addr, host_info->h_addr, host_info->h_length);

        // Connect to the server
        if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
            close(sock);
            return "Connection error";
        }

        // Create the HTTP GET request
        std::string request = "GET " + path + " HTTP/1.1\r\n"
                            "Host: " + hostname + "\r\n"
                            "Connection: close\r\n"
                            "\r\n";

        // Send the request
        if (send(sock, request.c_str(), request.length(), 0) == -1) {
            close(sock);
            return "Request sending error";
        }

        // Receive the response
        char buffer[BUFFER_SIZE];
        std::string response;
        int bytes_received;
        while ((bytes_received = recv(sock, buffer, BUFFER_SIZE - 1, 0)) > 0) {
            buffer[bytes_received] = '\0';
            response += buffer;
        }

        // Close the socket
        close(sock);

        // Extract the content from the HTTP response
        size_t content_start = response.find("\r\n\r\n");
        if (content_start != std::string::npos) {
            content_start += 4; // Skip the CRLF pair
            return response.substr(content_start);
        } else {
            return "Invalid HTTP response";
        }
    }

    void InsertWebPage(const std::string& url, const std::string& content) {
        // Check if cache is full, and evict the LRU page if necessary
        if (cache_map.size() >= cache_size) {
            cache_map.erase(cache_list.back().url);
            cache_list.pop_back();
        }

        // Create a new web page and insert it at the front of the list
        WebPage new_page = {url, content};
        cache_list.push_front(new_page);
        cache_map[url] = new_page;
    }
};

int main() {
    int c_size;
    std::cout<<"Please enter the intended cache size..."<<std::endl;
    std::cin>>c_size;
    WebCache cache(c_size);
    while (true) {
        std::string url;
        std::cout << "Enter a URL (or 'q' to quit): ";
        std::cin >> url;

        if (url == "q") {
            break;
        }

        std::string content = cache.GetWebPage(url);
        std::cout << "\033[1;31mWeb Page Content:\n\033[0m\n" << content << std::endl;
        std::cout << "\033[1;31mCache Contents (Most to Least Recently Used):\n\033[0m\n";
        cache.DisplayCache();
 
    }

    return 0;
}
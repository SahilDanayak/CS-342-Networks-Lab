#include <netinet/in.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <unistd.h>
#include <bits/stdc++.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netdb.h>

#define MSG_LEN 1024
#define MAX_CLIENTS 10
using namespace std;



unordered_map<string,int> mp;

string map_to_string(){
    string st="";
    for (auto it=mp.begin();it!=mp.end();it++){
        st+=((*it).first+" "+to_string((*it).second)+" ");
    }
    return st;
}

bool IsPortOpen(const string& host, int port,const string& message) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) return false;

    sockaddr_in server_addr = {AF_INET, htons(port)};
    hostent* host_info = gethostbyname(host.c_str());

    if (inet_pton(AF_INET, host.c_str(), &server_addr.sin_addr)<= 0) {
        return false;
    }

    if (!host_info || connect(sock, (sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
        close(sock);
        return false;
    }


    if (message.size()!=0){
        char msg_send[MSG_LEN] = { 0 };
        strcpy(msg_send,message.c_str());
        send(sock,msg_send, strlen(msg_send), 0);
    }

    close(sock);
    return true;
}

int main(int argc, char const* argv[])
{

    if (argc!=2){
        cout<<"Please enter 1 argument"<<endl;
        cout<<"1st argument is Port number"<<endl;
        return -1;
    }


    int server_fd, new_socket, valread;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    int PORT=stoi(argv[1]);


    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Forcefully attaching socket to the port
    if (setsockopt(server_fd, SOL_SOCKET,SO_REUSEADDR | SO_REUSEPORT, &opt,sizeof(opt))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
  
    // Forcefully attaching socket to the port
    // if bind==0 it indicates successful connection
    bind(server_fd, (struct sockaddr*)&address,sizeof(address));
    // if (bind(server_fd, (struct sockaddr*)&address,sizeof(address)) < 0) {
    //     perror("bind failed");
    //     exit(EXIT_FAILURE);
    // }

    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }
    cout<<"Server Successfully started"<<endl;

    pid_t id = 0;
    id = fork();

    if( id == 0 ) {

        //Child Process

        while (true){
            if ((new_socket= accept(server_fd, (struct sockaddr*)&address,(socklen_t*)&addrlen))< 0) {
                perror("accept");
                exit(EXIT_FAILURE);
            }
        
            char buffer[MSG_LEN] = { 0 };
            valread = read(new_socket, buffer, MSG_LEN);

            if (buffer[1]=='o'){
                // Case of creating a new connection.
                string output;
                if (mp.size()==MAX_CLIENTS){output="MAX CLIENT";}
                else {
                    cout<<"Log : New connection , socket fd is "<<new_socket<<" , ip is : "<<inet_ntoa(address.sin_addr)<<" , port : "<<ntohs(address.sin_port)<<endl;
                    string user="",port="";
                    int i=8;        //removing word connect
                    while (buffer[i]!=' '){user+=buffer[i++];}
                    i++;
                    while (buffer[i]!=' '){port+=buffer[i++];}
                    cout<<"\x1b[032m"<<user<<" joined the chatroom"<<endl<<"\x1b[0m";
                    mp[user]=stoi(port);
                    output= user + port;
                }

                strcpy(buffer,output.c_str());
                send(new_socket, buffer, strlen(buffer), 0);      //if error occurs, this returns number of bytes sent
            }

            else if (buffer[1]=='e'){
                // Case of getting all connections.

                //Checking if all connections exist and getting all connections

                vector<string> deluser;
                for (auto it=mp.begin();it!=mp.end();it++){
                    int prt=(*it).second;
                    string msg="";
                    if (!IsPortOpen("0.0.0.0",prt,msg)){deluser.push_back((*it).first);}
                }

                for (const auto &ele:deluser){
                    cout<<"\x1b[032m"<<ele<<" left the chatroom"<<endl<<"\x1b[0m";
                    if (mp.find(ele)!=mp.end()){mp.erase(ele);}
                }

                // cout<<"MAP: "<<map_to_string()<<endl;
                string output=map_to_string();
                strcpy(buffer,output.c_str());
                send(new_socket, buffer, strlen(buffer), 0);      //if error occurs, this returns number of bytes sent
            }

            else if (buffer[1]=='l'){
                // Case of closing a connection.
                string msg=buffer;
                string user=msg.substr(6);
                cout<<"\x1b[032m"<<user<<" left the chatroom"<<endl<<"\x1b[0m";
                string output= user + to_string(mp[user]);
                if (mp.find(user)!=mp.end()) mp.erase(user);
                strcpy(buffer,output.c_str());
                send(new_socket, buffer, strlen(buffer), 0);      //if error occurs, this returns number of bytes sent
            }

            else if (buffer[1]=='x'){
                //Case of exiting from server
                for (auto it=mp.begin();it!=mp.end();it++){
                    int prt=(*it).second;
                    string msg="/exit2";
                    IsPortOpen("0.0.0.0",prt,msg);
                }

            }
            else {
                cout<<buffer<<endl;
            }
        
            // closing the connected socket
            close(new_socket);
        }



    } else if( id == -1 ) {
            printf( "Error forking." );
    } else {

            //parent process
            
            string st;
            while (st!="/exit"){
                cin>>st;
            }
            string msg="exit";
            IsPortOpen("0.0.0.0",PORT,msg);
            sleep(2);
            kill( id, SIGINT );
            return 0;
    }
 

    // closing the listening socket
    shutdown(server_fd, SHUT_RDWR);
    return 0;
}
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <bits/stdc++.h>
#include <ctime>
#include "base64.hpp"       //header file for including base64 encoding and decoding

using namespace std;

#define MSG_LEN 1024


int main(int argc, char const* argv[])
{
    int status, valread, client_fd;
    struct sockaddr_in serv_addr;

    //checking for the correction of commandline arguments.

    if (argc!=3){
        cout<<"Please enter 2 arguments"<<endl;
        cout<<"1st argument is port number"<<endl;
        cout<<"2nd argument is ip address"<<endl;
        return -1;
    }

    //creating variables and getting data from commandline arguments

    char ip_address[20];
    strcpy(ip_address,argv[1]);
    int PORT=stoi(argv[2]);

    // creating char arrays to store received and transmitted messages 

    char msg[MSG_LEN]={0};
    char encoded_msg[2*MSG_LEN]={0};
    char buffer[MSG_LEN] = { 0 };
    bool server_open=1;

    //checking if a TCP socket can be created

    if ((client_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
        cout<<"\n Socket creation error \n";
        return -1;
    }

    //adding details of server to serv_addr
  
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
  
    // Convert IPv4 and IPv6 addresses from text to binary form

    if (inet_pton(AF_INET, ip_address, &serv_addr.sin_addr)<= 0) {
        cout<<"\nInvalid address/ Address not supported \n";
        return -1;
    }

    //Trying to connect to the server
  
    if ((status= connect(client_fd, (struct sockaddr*)&serv_addr,sizeof(serv_addr)))< 0) {
        cout<<"\nConnection Failed \n";
        return -1;
    }

    cout<<"\nConnected to server on "<<inet_ntoa(serv_addr.sin_addr)<<" and port "<< ntohs(serv_addr.sin_port) <<"\n"<<endl;
    
    cout<<"Enter your message : "<<endl;
    cout<<"Enter /exit to stop. "<<endl;
    cout<<"Functions : /timestamp"<<endl<<endl;
    cout<<"Client : ";

    cin.getline (msg,MSG_LEN);

    //Run the loop till a type 3 message is found

    while (strcmp(msg,"/exit")!=0){
        
        // Timestamp function
        while (strcmp(msg,"/timestamp")==0){
            time_t t; // t passed as argument in function time()
            struct tm * tt; // decalring variable for localtime()
            time (&t); //passing argument to time()
            tt = localtime(&t);
            cout << "Current Day, Date and Time is "<< asctime(tt);
            cout<<"Client : ";
            cin.getline (msg,MSG_LEN);
        }
        
        //encoding the message and sending it to the server
        string encoded=encodeBase64(msg);
        strcpy(encoded_msg, encoded.c_str());
        send(client_fd,encoded_msg, strlen(encoded_msg), 0);
        cout<<"Message sent"<<endl;

        //reading reply from server
        valread = read(client_fd, buffer, MSG_LEN);
        buffer[valread] = '\0';
        string reply = decodeBase64(buffer);
        if (reply.size()==0){cout<<"\nServer Unexpectedly closed\n";server_open=0;break;}
        cout<<"Server : "<<reply<<endl;

        cout<<"Client : ";
        cin.getline (msg,MSG_LEN);
    }

    //Normal termination of the program and sending the exit message to server to disconnect the connection

    if (server_open){
        string encoded=encodeBase64(msg);
        strcpy(encoded_msg, encoded.c_str());
        send(client_fd,encoded_msg, strlen(encoded_msg), 0);
    }

    cout<<"Quitting.."<<endl;
  
    // closing the connected socket
    close(client_fd);
    return 0;
}
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h> //Used for obtaining FD_SET, FD_ISSET, FD_ZERO macros 
#include<bits/stdc++.h>
#include "base64.hpp"
using namespace std;
     
#define MSG_LEN 1024 
#define MAX_CLIENTS 30
     
int main(int argc , char *argv[])  
{  
    int opt = true;  
    int master_socket , addrlen , new_socket , client_socket[MAX_CLIENTS] , activity, i , valread , sd;  
    int max_sd;  
    struct sockaddr_in address; 

    //checking for the correction of commandline arguments.

    if (argc!=2){
        cout<<"Please enter a argument"<<endl;
        cout<<"1st argument is port number"<<endl;
        return -1;
    }

    int PORT=stoi(argv[1]); 
         
    char buffer[2*MSG_LEN];  //data buffer of length 2 times the message length as encrypted message is approximately 4/3 times longer than the original message
         
    //set of socket descriptors 
    fd_set readfds;         //used for handeling multiple sockets
     
    //initialise all client_socket[] to 0 so not checked 
    for (i = 0; i < MAX_CLIENTS; i++)  
    {  
        client_socket[i] = 0;  
    }  
         
    //create a master socket with TCP protocol
    if( (master_socket = socket(AF_INET , SOCK_STREAM , IPPROTO_TCP)) == 0)  
    {  
        perror("socket failed");  
        exit(EXIT_FAILURE);  
    }  
     

    //setting master socket to allow multiple connections 
    if( setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) < 0 )  
    {  
        perror("setsockopt");  
        exit(EXIT_FAILURE);  
    }  
     
    //type of socket created 
    //adding details of server to address
    address.sin_family = AF_INET;  
    address.sin_addr.s_addr = INADDR_ANY;  
    address.sin_port = htons( PORT );  
         
    //bind the socket to localhost port 
    if (bind(master_socket, (struct sockaddr *)&address, sizeof(address))<0)  
    {  
        perror("bind failed");  
        exit(EXIT_FAILURE);  
    }  
    cout<<"Successfully started!!"<<endl;
    cout<<"Listening on port "<<PORT<<endl; 
         
    //try to specify maximum of 3 pending connections for the master socket 
    if (listen(master_socket, 3) < 0)  
    {  
        perror("listen");  
        exit(EXIT_FAILURE);  
    }  
         
    //accept the incoming connection 
    addrlen = sizeof(address);  
    cout<<"Waiting for connections ..."<<endl<<endl;

         
    while(true)  
    {  
        //clear the socket set 
        FD_ZERO(&readfds);  
     
        //add master socket to set 
        FD_SET(master_socket, &readfds);  
        max_sd = master_socket;  
             
        //add child sockets to set 
        for ( i = 0 ; i < MAX_CLIENTS ; i++)  
        {  
            //socket descriptor 
            sd = client_socket[i];  
                 
            //if valid socket descriptor then add to read list 
            if(sd > 0)  
                FD_SET( sd , &readfds);  
                 
            //highest file descriptor number, need it for the select function 
            if(sd > max_sd)  
                max_sd = sd;  
        }  
     
        //wait for an activity on one of the sockets , timeout is NULL , 
        //so wait indefinitely 
        activity = select( max_sd + 1 , &readfds , NULL , NULL , NULL);  
       
        if ((activity < 0) && (errno!=EINTR))  
        {  
            cout<<"Select Error"<<endl;
        }  
             
        //If something happened on the master socket , 
        //then its an incoming connection 
        if (FD_ISSET(master_socket, &readfds))  
        {  
            if ((new_socket = accept(master_socket, 
                    (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)  
            {  
                perror("accept");  
                exit(EXIT_FAILURE);  
            }  
             
            //inform user of socket number - used in send and receive commands 
            cout<<"New connection , socket fd is "<<new_socket<<" , ip is : "<<inet_ntoa(address.sin_addr)<<" , port : "<<ntohs(address.sin_port)<<endl;
                 
            //add new socket to array of sockets 
            for (i = 0; i < MAX_CLIENTS; i++)  
            {  
                //if position is empty 
                if( client_socket[i] == 0 )  
                {  
                    client_socket[i] = new_socket;  
                    cout<<"Adding to list of sockets as "<<i<<"\n"<<endl;                           
                    break;  
                }  
            } 
            cout<<endl; 
        }  
             
        //else its some IO operation on some other socket
        for (i = 0; i < MAX_CLIENTS; i++)  
        {  
            sd = client_socket[i];  
                 
            if (FD_ISSET( sd , &readfds))  
            {  
                //Check if it was for closing , and also read the incoming message 
                valread = read( sd , buffer, 2*MSG_LEN);
                if (valread== 0)  
                {  
                    //Somebody disconnected , get his details and print them
                    getpeername(sd , (struct sockaddr*)&address , \
                        (socklen_t*)&addrlen);  
                    cout<<endl<<"Received exiting message from client socket fd "<<sd<<endl;
                    cout<<"Host disconnected , ip "<<inet_ntoa(address.sin_addr)<<" , port "<<ntohs(address.sin_port)<<endl<<endl;   
                         
                    //Close the socket and mark as 0 in list for reuse 
                    close( sd );  
                    client_socket[i] = 0;  
                }  
                     
                //Echo back the message that came in 
                else 
                {  
                    //set the string terminating NULL byte on the end of the data read 
                    buffer[valread] = '\0';  
                    cout<<"Received encrypted message from client socket fd "<<sd<<": "<<buffer<<endl;

                    //decoding the char array

                    string decoded=decodeBase64(buffer);
                    cout<<"Decoded Message : "<<decoded<<endl;
                    if (decoded=="/exit"){continue;}

                    //Asking for user reply

                    cout<<"Enter your reply : ";
                    cin.getline(buffer,MSG_LEN);
                    string encoded=encodeBase64(buffer);
                    strcpy(buffer,encoded.c_str());
                    send(sd, buffer, strlen(buffer), 0);      //if error occurs, this returns number of bytes sent
                    cout<<"Reply message sent\n\n";
                }  
            }  
        }  
    }  
         
    return 0;  
} 
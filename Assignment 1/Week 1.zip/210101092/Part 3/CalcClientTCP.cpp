#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <netdb.h>
#include <bits/stdc++.h>
using namespace std;

#define MSG_LEN 1024

string HostToIp(const string& host) {
    hostent* hostname = gethostbyname(host.c_str());
    if(hostname)
        return string(inet_ntoa(**(in_addr**)hostname->h_addr_list));
    return {};
}

bool isfloat(const string &s){
    bool found_dot=0;
    for (int i=0;i<s.size();i++){
        char ele=s[i];
        if (i==0 and ele=='-') continue;
        if (ele<='9' and ele>='0') continue;
        if (ele=='.' and !found_dot) found_dot=1;
        else {return 0;}
    }
    return 1;
}

bool valid_msg(const string &s, long double &x1,long double &x2,char &op){
    string s1="";
    int index=0;
    for (int i=0;i<s.size();i++){
        if (s[i]==' ') {index=i+1;break;}
        s1.push_back(s[i]);
    }
    if (!isfloat(s1)){return 0;}
    x1=stof(s1);
    s1="";
    op=s[index++];
    if (op!='+' and op!='-' and op!='*' and op!='/' and op!='^') return 0;
    if (s[index++]!=' ') return 0;
    for (int i=index;i<s.size();i++){
        if (s[i]==' ') {index=i+1;break;}
        s1.push_back(s[i]);
        index=i;
    }
    if (!isfloat(s1)){return 0;}
    x2=stof(s1);
    if (index!=s.size()-1) return 0;
    return 1;
}
  

int main(int argc, char const* argv[])
{

    int status, valread, client_fd;
    struct sockaddr_in serv_addr;
    if (argc!=3){
        cout<<"Please enter 2 arguments"<<endl;
        cout<<"1st argument is ip address"<<endl;
        cout<<"2nd argument is port number"<<endl;
        return -1;
    }

    char ip_address[20];
    string ip=HostToIp(argv[1]);
    if (ip==""){
        strcpy(ip_address,argv[1]);
    }
    else {
        strcpy(ip_address,ip.c_str());
    }
    int PORT=stoi(argv[2]);
    char msg[MSG_LEN]={0};
    char buffer[MSG_LEN] = { 0 };
    bool server_open=1;

    if ((client_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
        cout<<"\n Socket creation error \n";
        return -1;
    }
  
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
  
    // Convert IPv4 and IPv6 addresses from text to binary form
    if (inet_pton(AF_INET, ip_address, &serv_addr.sin_addr)<= 0) {
        cout<<"\nInvalid address/ Address not supported \n";
        return -1;
    }
  
    if ((status= connect(client_fd, (struct sockaddr*)&serv_addr,sizeof(serv_addr)))< 0) {
        cout<<"\nConnection Failed \n";
        return -1;
    }
    
    cout<<"\nConnected to server with ip "<<argv[2]<<" on port "<<argv[1]<<".\n"<<endl;

    cout<<"Enter expression in the following format: "<<endl;
    cout<<"Operand1 operator Operand2"<<endl;
    cout<<"Operand: Any real Number"<<endl;
    cout<<"Operator: +,-,*,/,^"<<endl;
    cout<<"To quit enter -1"<<endl;
    cin.getline (msg,MSG_LEN);
    
    while (true){
        long double x,y;char op;
        // for (int i=0;i<3;i++){cout<<msg[i]<<" ";}
        // cout<<sizeof(msg)<<" "<<strlen(msg)<<endl;
        if (strlen(msg)==2 and msg[0]=='-' and msg[1]=='1'){cout<<"Received exiting message"<<endl;break;}
        while (!valid_msg(msg,x,y,op)){
            cout<<"Invalid Message! Please try again"<<endl;
            cin.getline (msg,MSG_LEN);
        }
        send(client_fd,msg, strlen(msg), 0);

        valread = read(client_fd, buffer, MSG_LEN);
        buffer[valread] = '\0';
        if (valread==0){cout<<"\nServer Unexpectedly closed\n";server_open=0;break;}
        cout<<"Answer: "<<msg<<" = "<<buffer<<endl<<endl;

        cout<<"Enter expression in the following format: "<<endl;
        cout<<"Operand1 operator Operand2"<<endl;
        cout<<"Operand: Any real Number"<<endl;
        cout<<"Operator: +-*/"<<endl;
        cout<<"To quit enter -1"<<endl;
        cin.getline (msg,MSG_LEN);
    }


    cout<<"Quitting.."<<endl;
  
    // closing the connected socket
    close(client_fd);
    return 0;
}
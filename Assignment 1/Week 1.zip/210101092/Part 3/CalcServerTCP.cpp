//Example code: A simple server side code, which echos back the received message.
//Handle multiple socket connections with select and fd_set on Linux 
#include <stdio.h> 
#include <string.h>   //strlen 
#include <stdlib.h> 
#include <errno.h> 
#include <unistd.h>   //close 
#include <arpa/inet.h>    //close 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <sys/time.h> //FD_SET, FD_ISSET, FD_ZERO macros 
#include<bits/stdc++.h>
using namespace std;
     
#define MSG_LEN 1024 
#define MAX_CLIENTS 30

bool isfloat(const string &s){
    bool found_dot=0;
    for (int i=0;i<s.size();i++){
        char ele=s[i];
        if (i==0 and ele=='-') continue;
        if (ele<='9' and ele>='0') continue;
        if (ele=='.' and !found_dot) found_dot=1;
        else {return 0;}
    }
    return 1;
}

bool valid_msg(const string &s, long double &x1,long double &x2,char &op){
    string s1="";
    int index=0;
    for (int i=0;i<s.size();i++){
        if (s[i]==' ') {index=i+1;break;}
        s1.push_back(s[i]);
    }
    if (!isfloat(s1)){return 0;}
    x1=stof(s1);
    s1="";
    op=s[index++];
    if (op!='+' and op!='-' and op!='*' and op!='/' and op!='^') return 0;
    if (s[index++]!=' ') return 0;
    for (int i=index;i<s.size();i++){
        if (s[i]==' ') {index=i+1;break;}
        s1.push_back(s[i]);
        index=i;
    }
    if (!isfloat(s1)){return 0;}
    x2=stof(s1);
    if (index!=s.size()-1) return 0;
    return 1;


}

string solve (long double x1,long double x2,char op){
    long double result=0;
    bool flag=1;
    switch (op){
        case '+':
            result=x1+x2;break;
        case '-':
            result=x1-x2;break;
        case '*':
            result=x1*x2;break;
        case '/':
            if (x2==0) {flag=0;break;}
            result=x1/x2;
            break;
        case '^':
            result= pow(x1,x2);
            break;
        default:
            flag=0;break;
    }
    string st= to_string(result);
    if (!flag) st="Error while solving!!";
    return st;
}


int main(int argc , char *argv[])  
{  
    int opt = true;  
    int master_socket , addrlen , new_socket , client_socket[MAX_CLIENTS], activity, i , valread , sd;  
    int max_sd;  
    struct sockaddr_in address; 
    if (argc!=2){
        cout<<"Please enter a argument"<<endl;
        cout<<"1st argument is port number"<<endl;
        return -1;
    }

    int PORT=stoi(argv[1]); 
         
    char buffer[MSG_LEN];  //data buffer of 1K 
         
    //set of socket descriptors 
    fd_set readfds;  
     
    //initialise all client_socket[] to 0 so not checked 
    for (i = 0; i < MAX_CLIENTS; i++)  
    {  
        client_socket[i] = 0;  
    }  
         
    //create a master socket 
    if( (master_socket = socket(AF_INET , SOCK_STREAM , IPPROTO_TCP)) == 0)  
    {  
        perror("socket failed");  
        exit(EXIT_FAILURE);  
    }  
     
    //set master socket to allow multiple connections , 
    //this is just a good habit, it will work without this 
    if( setsockopt(master_socket, SOL_SOCKET, SO_REUSEADDR, (char *)&opt, sizeof(opt)) < 0 )  
    {  
        perror("setsockopt");  
        exit(EXIT_FAILURE);  
    }  
     
    //type of socket created 
    address.sin_family = AF_INET;  
    address.sin_addr.s_addr = INADDR_ANY;  
    address.sin_port = htons( PORT );  
         
    //bind the socket to localhost port 8888 
    if (bind(master_socket, (struct sockaddr *)&address, sizeof(address))<0)  
    {  
        perror("bind failed");  
        exit(EXIT_FAILURE);  
    }  
    cout<<"Successfully started!!"<<endl;
    cout<<"Listening on port "<<PORT<<endl; 
         
    //try to specify maximum of 3 pending connections for the master socket 
    if (listen(master_socket, 3) < 0)  
    {  
        perror("listen");  
        exit(EXIT_FAILURE);  
    }  
         
    //accept the incoming connection 
    addrlen = sizeof(address);  
    cout<<"Waiting for connections ..."<<endl<<endl;

    while(true)  
    {  
        //clear the socket set 
        FD_ZERO(&readfds);  
     
        //add master socket to set 
        FD_SET(master_socket, &readfds);  
        max_sd = master_socket;  
             
        //add child sockets to set 
        for ( i = 0 ; i < MAX_CLIENTS ; i++)  
        {  
            //socket descriptor 
            sd = client_socket[i];  
                 
            //if valid socket descriptor then add to read list 
            if(sd > 0)  
                FD_SET( sd , &readfds);  
                 
            //highest file descriptor number, need it for the select function 
            if(sd > max_sd)  
                max_sd = sd;  
        }  
     
        //wait for an activity on one of the sockets , timeout is NULL , 
        //so wait indefinitely 
        activity = select( max_sd + 1 , &readfds , NULL , NULL , NULL);  
       
        if ((activity < 0) && (errno!=EINTR))  
        {  
            cout<<"Select Error"<<endl;
        }  
             
        //If something happened on the master socket , 
        //then its an incoming connection 
        if (FD_ISSET(master_socket, &readfds))  
        {  
            if ((new_socket = accept(master_socket, 
                    (struct sockaddr *)&address, (socklen_t*)&addrlen))<0)  
            {  
                perror("accept");  
                exit(EXIT_FAILURE);  
            }  
             
            //inform user of socket number - used in send and receive commands 
            printf("New connection , socket fd is %d , ip is : %s , port : %d \n" , new_socket , inet_ntoa(address.sin_addr) , ntohs(address.sin_port));  
                 
            //add new socket to array of sockets 
            for (i = 0; i < MAX_CLIENTS; i++)  
            {  
                //if position is empty 
                if( client_socket[i] == 0 )  
                {  
                    client_socket[i] = new_socket;  
                    printf("Adding to list of sockets as %d\n" , i);  
                         
                    break;  
                }  
            } 
            if (i==MAX_CLIENTS){cout<<"Max ports connected. Unable to receive more connections"<<endl;}
            cout<<endl; 
        }  
             
        //else its some IO operation on some other socket
        for (i = 0; i < MAX_CLIENTS; i++)  
        {  
            sd = client_socket[i];  
                 
            if (FD_ISSET( sd , &readfds))  
            {  
                //Check if it was for closing , and also read the 
                //incoming message 
                // char buffer[2*MSG_LEN] = { 0 };
                valread = read( sd , buffer, MSG_LEN);
                if (valread== 0)  
                {  
                    //Somebody disconnected , get his details and print 
                    getpeername(sd , (struct sockaddr*)&address , \
                        (socklen_t*)&addrlen);  
                    cout<<endl<<"Received exiting message from client socket fd "<<sd<<endl;
                    printf("Host disconnected , ip %s , port %d \n\n" , 
                          inet_ntoa(address.sin_addr) , ntohs(address.sin_port));  
                         
                    //Close the socket and mark as 0 in list for reuse 
                    close( sd );  
                    client_socket[i] = 0;  
                }  
                     
                //Echo back the message that came in 
                else 
                {  
                    //set the string terminating NULL byte on the end 
                    //of the data read 
                    buffer[valread] = '\0';  
                    cout<<"Received message from client-socket fd "<<sd<<": "<<buffer<<endl;
                    long double x,y;
                    char op;
                    string msg;
                    if (!valid_msg(buffer,x,y,op)){msg="Server didn't get a valid message";}
                    else {msg=solve(x,y,op);}
                    strcpy(buffer,msg.c_str());
                    send(sd, buffer, strlen(buffer), 0);      //if error occurs, this returns number of bytes sent
                    cout<<"Answer sent as "<<msg<<endl<<endl;
                }  
            }  
        }  
    }  
         
    return 0;  
} 
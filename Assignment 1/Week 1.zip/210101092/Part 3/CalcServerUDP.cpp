
// Server side implementation of UDP client-server model
#include <bits/stdc++.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

using namespace std;
#define MSG_LEN 1024
#define MAX_CLIENTS 30

bool isfloat(const string &s){
    bool found_dot=0;
    for (int i=0;i<s.size();i++){
        char ele=s[i];
        if (i==0 and ele=='-') continue;
        if (ele<='9' and ele>='0') continue;
        if (ele=='.' and !found_dot) found_dot=1;
        else {return 0;}
    }
    return 1;
}

bool valid_msg(const string &s, long double &x1,long double &x2,char &op){
    string s1="";
    int index=0;
    for (int i=0;i<s.size();i++){
        if (s[i]==' ') {index=i+1;break;}
        s1.push_back(s[i]);
    }
    if (!isfloat(s1)){return 0;}
    x1=stof(s1);
    s1="";
    op=s[index++];
    if (op!='+' and op!='-' and op!='*' and op!='/' and op!='^') return 0;
    if (s[index++]!=' ') return 0;
    for (int i=index;i<s.size();i++){
        if (s[i]==' ') {index=i+1;break;}
        s1.push_back(s[i]);
        index=i;
    }
    if (!isfloat(s1)){return 0;}
    x2=stof(s1);
    if (index!=s.size()-1) return 0;
    return 1;


}

string solve (long double x1,long double x2,char op){
    long double result=0;
    bool flag=1;
    switch (op){
        case '+':
            result=x1+x2;break;
        case '-':
            result=x1-x2;break;
        case '*':
            result=x1*x2;break;
        case '/':
            if (x2==0) {flag=0;break;}
            result=x1/x2;
            break;
        case '^':
            result= pow(x1,x2);
            break;
        default:
            flag=0;break;
    }
    string st= to_string(result);
    if (!flag) st="Error while solving!!";
    return st;
}
   
// Driver code
int main(int argc , char *argv[]) {
    int sockfd,port[MAX_CLIENTS];
    char buffer[MSG_LEN];
    struct sockaddr_in servaddr, cliaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    memset(&cliaddr, 0, sizeof(cliaddr));
    memset(&port,0,sizeof(port));
    socklen_t len;
    len = sizeof(cliaddr);  //len is value/result

    if (argc!=2){
        cout<<"Please enter a argument"<<endl;
        cout<<"1st argument is port number"<<endl;
        return -1;
    }

    int PORT=stoi(argv[1]); 
       
    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
       
    // Filling server information
    servaddr.sin_family    = AF_INET; // IPv4
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);
       
    // Bind the socket with the server address
    if ( bind(sockfd, (const struct sockaddr *)&servaddr, 
            sizeof(servaddr)) < 0 )
    {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    cout<<"Successfully started!!"<<endl;
    cout<<"Listening on port "<<PORT<<endl;
    cout<<"Waiting for connections ..."<<endl<<endl;
 


    while (true){
        int valread = recvfrom(sockfd, (char *)buffer, MSG_LEN, MSG_WAITALL, ( struct sockaddr *) &cliaddr,&len);
        buffer[valread] = '\0';

        int found=-1;
        int index=-1;
        for (int i = 0; i < MAX_CLIENTS; i++)  
        {  
            if (port[i]==cliaddr.sin_port){found=i;}
            if (port[i]==0){index=i;}
        }  
        if (found==-1){
            cout<<"A new connection established from port "<<ntohs(cliaddr.sin_port)<<" on ip address "<<inet_ntoa(cliaddr.sin_addr)<<endl<<endl;
            port[index]=cliaddr.sin_port;
        }
        if (strlen(buffer)==2 and buffer[0]=='-' and buffer[1]=='1'){
            cout<<"Connection deleted from port "<<ntohs(cliaddr.sin_port)<<" on ip address "<<inet_ntoa(cliaddr.sin_addr)<<endl<<endl;
            port[found]=0;
            continue;
        }
        
        cout<<"Received message from client port "<<ntohs(cliaddr.sin_port)<<": "<<buffer<<endl;

        long double x,y;
        char op;
        string msg;
        if (!valid_msg(buffer,x,y,op)){msg="Server didn't get a valid message";}
        else {msg=solve(x,y,op);}
        strcpy(buffer,msg.c_str());
        sendto(sockfd, (const char *)buffer, strlen(buffer), 
            MSG_CONFIRM, (const struct sockaddr *) &cliaddr,
                len);
        cout<<"Answer sent as "<<msg<<endl<<endl;
    }

   

       
    return 0;
}
// Client side implementation of UDP client-server model
#include <bits/stdc++.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
   
using namespace std;

#define MSG_LEN 1024

string HostToIp(const string& host) {
    hostent* hostname = gethostbyname(host.c_str());
    if(hostname)
        return string(inet_ntoa(**(in_addr**)hostname->h_addr_list));
    return {};
}

bool isfloat(const string &s){
    bool found_dot=0;
    for (int i=0;i<s.size();i++){
        char ele=s[i];
        if (i==0 and ele=='-') continue;
        if (ele<='9' and ele>='0') continue;
        if (ele=='.' and !found_dot) found_dot=1;
        else {return 0;}
    }
    return 1;
}

bool valid_msg(const string &s, long double &x1,long double &x2,char &op){
    string s1="";
    int index=0;
    for (int i=0;i<s.size();i++){
        if (s[i]==' ') {index=i+1;break;}
        s1.push_back(s[i]);
    }
    if (!isfloat(s1)){return 0;}
    x1=stof(s1);
    s1="";
    op=s[index++];
    if (op!='+' and op!='-' and op!='*' and op!='/' and op!='^') return 0;
    if (s[index++]!=' ') return 0;
    for (int i=index;i<s.size();i++){
        if (s[i]==' ') {index=i+1;break;}
        s1.push_back(s[i]);
        index=i;
    }
    if (!isfloat(s1)){return 0;}
    x2=stof(s1);
    if (index!=s.size()-1) return 0;
    return 1;


}

   
// Driver code
int main(int argc, char const* argv[]) {
    int sockfd;
    struct sockaddr_in servaddr;
    socklen_t len;
    memset(&servaddr, 0, sizeof(servaddr));

    if (argc!=3){
        cout<<"Please enter 2 arguments"<<endl;
        cout<<"1st argument is ip address"<<endl;
        cout<<"2nd argument is port number"<<endl;
        return -1;
    }

    char ip_address[20];
    string ip=HostToIp(argv[1]);
    if (ip==""){
        strcpy(ip_address,argv[1]);
    }
    else {
        strcpy(ip_address,ip.c_str());
    }
    int PORT=stoi(argv[2]);
    char msg[MSG_LEN]={0};
    char buffer[MSG_LEN] = { 0 };
    bool server_open=1;
   
    // Creating socket file descriptor
    if ( (sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
          
    // Filling server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = INADDR_ANY;


    cout<<"\nConnected to server with ip "<<argv[2]<<" on port "<<argv[1]<<".\n"<<endl;

    cout<<"Enter expression in the following format: "<<endl;
    cout<<"Operand1 operator Operand2"<<endl;
    cout<<"Operand: Any real Number"<<endl;
    cout<<"Operator: +,-,*,/,^"<<endl;
    cout<<"To quit enter -1"<<endl;
    cin.getline (msg,MSG_LEN);

    while (true){
        long double x,y;char op;
        if (strlen(msg)==2 and msg[0]=='-' and msg[1]=='1'){
            cout<<"Received exiting message"<<endl;
            sendto(sockfd, (const char *)msg, strlen(msg), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));
            break;
        }
        while (!valid_msg(msg,x,y,op)){
            cout<<"Invalid Message! Please try again"<<endl;
            cin.getline (msg,MSG_LEN);
        }
        sendto(sockfd, (const char *)msg, strlen(msg), MSG_CONFIRM, (const struct sockaddr *) &servaddr, sizeof(servaddr));

        int valread = recvfrom(sockfd, (char *)buffer, MSG_LEN, MSG_WAITALL, (struct sockaddr *) &servaddr, &len);;
        buffer[valread] = '\0';
        if (valread==0){cout<<"\nServer Unexpectedly closed\n";server_open=0;break;}
        cout<<"Answer: "<<msg<<" = "<<buffer<<endl<<endl;

        cout<<"Enter expression in the following format: "<<endl;
        cout<<"Operand1 operator Operand2"<<endl;
        cout<<"Operand: Any real Number"<<endl;
        cout<<"Operator: +-*/"<<endl;
        cout<<"To quit enter -1"<<endl;
        cin.getline (msg,MSG_LEN);
    }

    close(sockfd);
    return 0;
}
#include <bits/stdc++.h>

using namespace std;

int time_global=0;
int total_weight=0;

// HttpRequest class to represent incoming HTTP requests
class HttpRequest {
public:
    int id;
    int websiteId;
    int processingTime;

    HttpRequest(int requestId, int website, int processingTime)
        : id(requestId), websiteId(website), processingTime(processingTime) {}

    //Default constructor
    HttpRequest()
        : id(-1), websiteId(-1), processingTime(-1) {}
};

// Website class to represent websites hosted on the server cluster
class Website {
public:
    int id;
    int owner;
    int bandwidth;
    int processingPower;
    int weight;
    float prev_virtual_time=0;
    queue<HttpRequest> requestQueue;

    Website(int websiteId, int ownerId, int allocatedBandwidth, int allocatedProcessingPower)
        : id(websiteId), owner(ownerId), bandwidth(allocatedBandwidth), processingPower(allocatedProcessingPower),weight(allocatedProcessingPower+allocatedBandwidth) {}

    //Default constructor
    Website()
        : id(-1), owner(-1), bandwidth(-1), processingPower(-1),weight(-1) {}

};

// LoadBalancer class that implements WFQ
class LoadBalancer {
public:
    vector<Website> websites;

    // Add a new website to the system
    void add_website(Website website) {
        websites.emplace_back(website);
        total_weight+=website.weight;
    }

    // Enqueue an HTTP request into the corresponding website's queue
    bool enqueue_request(HttpRequest httpRequest) {
        bool found=false;
        for (Website& website : websites) {
            if (website.id == httpRequest.websiteId) {
                website.requestQueue.push(httpRequest);
                found=true;
                break;
            }
        }
        return found;
    }

    

    // Dequeue the next HTTP request based on the WFQ scheduling algorithm
    HttpRequest dequeue_request() {
        //finding minimum virtual time of website

        int index=-1;
        float mn=1e9;
        
        for (int i=0;i<websites.size();i++){
            if (websites[i].requestQueue.empty()){continue;}
            int processing_time= websites[i].requestQueue.front().processingTime;
            int weight=websites[i].weight;
            float virtual_time=websites[i].prev_virtual_time+ (processing_time*total_weight)/(weight*1.0);

            if (virtual_time<mn){mn=virtual_time;index=i;}
            if (virtual_time==mn and index!=-1 and websites[i].requestQueue.front().id<websites[index].requestQueue.front().id){index=i;}
        }

        if (index==-1){return HttpRequest(-1,-1,-1);}
        else {
            HttpRequest request = websites[index].requestQueue.front();
            websites[index].requestQueue.pop();
            websites[index].prev_virtual_time=mn;
            time_global+=request.processingTime;
            return request;
        }

        
    }
};

int main() {
    LoadBalancer loadBalancer;

    cout<<"Welcome to our program!!"<<endl<<"This program was created for Ques 1 of Networks Assignment 4"<<endl;
    cout<<"Please choose an option"<<endl;
    int opt=0;

    cout<<"\nEnter 1 for adding a new website."<<endl;
    cout<<"Enter 2 for adding a new Http Request to the queue."<<endl;
    cout<<"Enter 3 for dequeuing the queue."<<endl;
    cout<<"Enter 4 to exit."<<endl;
    cout<<"Choice: ";
    cin>>opt;
    cout<<endl;

    while (opt!=4){

        if (opt==1){
            int id,authorId,bandwidth,processingPower;
            cout<<"Enter Website id: ";
            cin>>id;
            cout<<"Enter Website Author id: ";
            cin>>authorId;
            cout<<"Enter Website bandwidth: ";
            cin>>bandwidth;
            cout<<"Enter Website processing power: ";
            cin>>processingPower;            
            loadBalancer.add_website(Website(id, authorId, bandwidth, processingPower));
        }
        else if (opt==2){
            int HTTPid,websiteId,processingTime;
            cout<<"Enter HTTP request id: ";
            cin>>HTTPid;
            cout<<"Enter Website id: ";
            cin>>websiteId;
            cout<<"Enter HTTP request Processing Time: ";
            cin>>processingTime;
            if (loadBalancer.enqueue_request(HttpRequest(HTTPid, websiteId, processingTime))){
                cout<<"Request enqueued Successfully"<<endl;
            }
            else {
                cout<<"No such website found."<<endl;
            }
        }
        else if (opt==3){
            HttpRequest nextRequest = loadBalancer.dequeue_request();
            if (nextRequest.id==-1){
                cout<<"No HTTP request in queue left."<<endl;
            }
            else {
                cout << "Processing request " << nextRequest.id << " for website " << nextRequest.websiteId << endl;
                cout<<"Request processed at time "<<time_global<<endl;
            }
        }
        else {
            cout<<"Incorrect Number entered"<<endl;
        }



        cout<<"\nEnter 1 for adding a new website."<<endl;
        cout<<"Enter 2 for adding a new Http Request to the queue."<<endl;
        cout<<"Enter 3 for dequeuing the queue."<<endl;
        cout<<"Enter 4 to exit."<<endl;
        cout<<"Choice: ";
        cin>>opt;
        cout<<endl;

    }

    cout<<"Bye!"<<endl;

    return 0;
}
